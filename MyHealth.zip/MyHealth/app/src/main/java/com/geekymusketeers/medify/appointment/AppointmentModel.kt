package com.geekymusketeers.medify.appointment

class AppointmentModel (var filename: String? = null, var fileurl:String? = null)
